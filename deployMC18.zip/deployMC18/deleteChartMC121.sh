cloudctl login -a https://secure.bluedemos.com:8443 -u admin -p icp1nCl0ud -c id-mycluster-account -n default
helm delete --purge microclimate --tls
kubectl delete persistentvolumeclaim mc-home
kubectl delete persistentvolumeclaim jenkins-home
kubectl delete secret microclimate-pipeline-secret -n microclimate-pipeline-deployments